#!/bin/ash

cp -rf /tempfs/apps/* /rootfs/apps/
cp -rf /tempfs/version.txt /rootfs/etc/
cp -rf /tempfs/rc.local /rootfs/etc/

rm -rf /rootfs/etc/supervisor/conf.d/frpc.conf

dd if=/tempfs/uboot.img of=/dev/mmcblk1p1
dd if=/tempfs/boot.img of=/dev/mmcblk1p4
sync
