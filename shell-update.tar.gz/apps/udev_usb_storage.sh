#!/bin/sh
umount /media/usb
mkdir /media/usb

#ver=""
sig_update()
{
	kill -s SIGUSR1 $1 
}
if [ $# != 2 ]; then
	exit 1;
fi
dev=$2
mnt_point=/media/usb
#ver=`udevinfo -a -p $(udevinfo -q path -n /dev/$dev) |grep ATTRS{vendor} |awk -F "==" '{print $2}'|awk -F"\"" '{print $2}'`


if [ $1 = "a" ]; then	
	mkdir -p $mnt_point
	mount -o iocharset=utf8,umask=0 /dev/$dev $mnt_point	
	sig_update `busybox pidof update`
elif [ $1 = "r" ]; then	
	for num in 1 2 3 4 5 6 7 8 9 ;
	do
		if [ -d ${mnt_poiont}${num} ]; then		
#			fuser -k ${mnt_point}${num}
			umount ${mnt_point}${num}
#			rm -rf ${mnt_point}${num}
		fi
	done
fi

#usleep 5000000


	
