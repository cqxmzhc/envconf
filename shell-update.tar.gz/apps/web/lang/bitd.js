

function atoi(str, num)
{
	i = 1;
	if (num != 1) {
		while (i != num && str.length != 0) {
			if (str.charAt(0) == '.') {
				i++;
			}
			str = str.substring(1);
		}
		if (i != num)
			return -1;
	}

	for (i=0; i<str.length; i++) {
		if (str.charAt(i) == '.') {
			str = str.substring(0, i);
			break;
		}
	}
	if (str.length == 0)
		return -1;
	return parseInt(str, 10);
}

function checkRange(str, num, min, max)
{
	d = atoi(str, num);
	if (d > max || d < min)
		return false;
	return true;
}

function isNumOnly(str)
{
	if ( str == "")
	{
		alert(_("error 1500"));
		return false;
	}
	
	for (var i=0; i<str.length; i++){
	    if((str.charAt(i) >= '0' && str.charAt(i) <= '9') )
			continue;
		alert(_("error 2050"));
		return false;
	}
	
	return true;
}

function isNumPoint(str)
{
	for (var i=0; i<str.length; i++) {
		if ((str.charAt(i) >= '0' && str.charAt(i) <= '9') || (str.charAt(i) == '.' ))
			continue;
		alert(_("error 2051"));
		return false;
	}
	return true;
}

function isNumPointSlash(str)
{
	for (var i=0; i<str.length; i++){
		if( (str.charAt(i) >= '0' && str.charAt(i) <= '9') || (str.charAt(i) == '.') || (str.charAt(i) == '/'))
			continue;
		alert(_("error 2052"));
		return false;
	}
	return true;
}

function checkIpAddr(field, ismask)
{
	if (field.value == "") {
		alert(_("error 2000"));
		field.select();
		return false;
	}

	if (isNumPoint(field.value) == 0) {
		field.select();
		return false;
	}

	if (ismask) {
		if ((!checkRange(field.value, 1, 0, 256)) ||
			(!checkRange(field.value, 2, 0, 256)) ||
			(!checkRange(field.value, 3, 0, 256)) ||
			(!checkRange(field.value, 4, 0, 256)))
		{
			alert(_("error 2001"));
			field.select();
			return false;
		}
	}
	else {
		if ((!checkRange(field.value, 1, 0, 255)) ||
			(!checkRange(field.value, 2, 0, 255)) ||
			(!checkRange(field.value, 3, 0, 255)) ||
			(!checkRange(field.value, 4, 1, 254)))
		{
			alert(_("error 2001"));
			field.select();
			return false;
		}
	}
	return true;
}

function checkIpAddrNoMask(field)
{
    if(field.value == ""){
        alert(_("error 2000"));
        field.select();
        return false;
    }

    if ( isNumPoint(field.value) == 0) {
        field.select();
        return false;
    }

    if( (!checkRange(field.value,1,0,255)) ||
        (!checkRange(field.value,2,0,255)) ||
        (!checkRange(field.value,3,0,255)) ||
        (!checkRange(field.value,4,0,255)) ){
        alert(_("error 2001"));
        field.select();
        return false;
    }

   return true;
}

function checkIpAddrSlash(field)
{
	if(field.value == ""){
        alert(_("error 2000"));
        field.select();
        return false;
    }

	if (isNumPointSlash(field.value) == 0){
        field.select();
        return false;
    }

	var ip_pair = new Array();
	ip_pair = field.value.split("/");

	if(ip_pair.length > 2){
        alert(_("error 2001"));
		return false;
	}

	if(ip_pair.length == 2){
		// sub mask
		if(!ip_pair[1].length)
		{
        	alert(_("error 2001"));
			return false;
		}
		
		if(!isNumOnly(ip_pair[1])){
        	field.select();
			return false;
		}
		
		tmp = parseInt(ip_pair[1], 10);
		if(tmp < 0 || tmp > 32){
        	alert(_("error 2001"));
        	field.select();
			return false;
		}
	}

    if( (!checkRange(ip_pair[0],1,0,255)) ||
		(!checkRange(ip_pair[0],2,0,255)) ||
		(!checkRange(ip_pair[0],3,0,255)) ||
		(!checkRange(ip_pair[0],4,0,254)) ){
        alert(_("error 2001"));
        field.select();
		return false;
    }
	return true;
}

function checkMacAddr(field)
{
	var re = /[A-Fa-f0-9]{2}:[A-Fa-f0-9]{2}:[A-Fa-f0-9]{2}:[A-Fa-f0-9]{2}:[A-Fa-f0-9]{2}:[A-Fa-f0-9]{2}/;
	if (!re.test(field.value)) {
		alert(_("error 3001"));
		field.select();
		return false;
	}
	
	return true;
}

function checkMacAddrEmpty(field)
{
	if (field.value.length == 0) {
		alert(_("error 3000"));
		field.select();
		return false;
	}
	
	if (!checkMacAddr(field))
		return false;	
		
	return true;
}
