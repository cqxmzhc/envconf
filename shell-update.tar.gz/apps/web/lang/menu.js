var cur_id=0;

function Node(id, pid, name, url) {

	this.id = id;

	this.pid = pid;

	this.name = name;

	this.url = url;
};

function dMenu(objName) {

	this.obj = objName;

	this.aNodes = [];

};

// Adds a new node to the node array

dMenu.prototype.add = function(id, pid, name, url)
{   
    this.aNodes[this.aNodes.length] = new Node(id, pid, name,url);
};


dMenu.prototype.toString = function()
{
    var str = '';
  
    var n=0;
    var id;
    var pid;
    var name;
    var url;

    for (n; n<this.aNodes.length; n++) 
    {
        id = this.aNodes[n].id;
        pid = this.aNodes[n].pid;
        name = this.aNodes[n].name;
        url = this.aNodes[n].url;

        if(pid==0)
        {
            str += "<A href=";
            str += url;
            str += " ><div id =";
            str += n;
            str += "  class=menu_root_normal  onmouseover=menu_root_over(";
            str += n;
            str += ")";
            str += " onmouseout=menu_root_out(";
            str += n;
            str += ")";
            str += " onclick=menu_root_click(";
            str += n;
            str += ")>";
            str += name;
            str += "</div></A><ul id=submenu_";
            str += n;
            str += " class=child_disp >";
            str += "</ul>";
        }
        else
        {
            str = str.substring(0, str.length-5);
            
            str += "<li id=";
            str += id;
            str += " >";
            str += "<A href=";
            str += url;
            str += " >"
            str += name;
            str += "</A>";
            str += "</li>";
       
            str += "</ul>";
        }

    }
 
    return str;
};

function menu_root_click(nid)
{
	if (document.getElementById("submenu_"+nid).className == "block")
	{
		document.getElementById("submenu_"+nid).className="child_disp";
	}
	else
	{
		document.getElementById("submenu_"+nid).className = "block";
	}

	if (cur_id != nid)
	{
		document.getElementById("submenu_"+cur_id).className="child_disp";
    	cur_id = nid;
	}
}

function menu_root_over(nid)
{ 
	document.getElementById(nid).className ="menu_root_over";
}

function menu_root_out(npid)
{
	document.getElementById(npid).className ="menu_root_normal";
}



